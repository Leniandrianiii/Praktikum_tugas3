# Tugas-3-RecyclerView-Intent---Prak-TPM
# RECYCLER VIEW & INTENT
Nama : Willian Kelvin Nata
\nNIM : 123180004
Praktikum Teknologi Pemrograman Mobile - Plug B
link youtube : https://youtu.be/oeSBYxLD2W8
