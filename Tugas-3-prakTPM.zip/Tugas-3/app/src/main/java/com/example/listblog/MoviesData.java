package com.example.listblog;

import java.util.ArrayList;

public class MoviesData {
    private static String[] movieNames = {
            "Petualangan Nobita di Negeri Wan Nyan",
            "Doraemon: Nobita di Negeri Angin",
            "Nobita di Kerajaan Robot",
            "Dinosaurus Baru Nobita",
            "Doraemon: Nobita dan Legenda Raja Matahari",
            "Doraemon: Nobita and the Birth of Japan 2016",
            "Pulau Harta Karun Nobita",
            "Nobita dan Pasukan Baja",
            "Stand by Me Doraemon",
            "Stand by Me Doraemon 2"
    };

    private static String[] movieDetails = {
            "adalah sebuah film anime Doraemon yang dirilis tahun 2004. Film ini memperingati 25 tahun seri televisi Doraemon di TV Asahi, dan 25 tahun film Doraemon. Film ini juga merupakan film terakhir Doraemon yang merupakan bagian dari edisi anime Doraemon tahun 1979 dan termasuk pemain asli.",
            "Doraemon: Nobita di Negeri Angin (ドラえもん のび太とふしぎ風使い Doraemon Nobita to Fushigi Kazetsukai) juga dikenal sebagai Doraemon: Nobita and the Windmasters atau Doraemon and the Wind People,[2] adalah sebuah film Doraemon jangka fitur yang tayang perdana pada 8 Maret 2003 di Jepang. Film tersebut adalah film Doraemon ke-24.",
            "Doraemon dan teman-temannya bertemu dengan bocah robot aneh dari mesin pemesanan futuristik. Melalui labirin ruang waktu yang sulit (mungkin lubang yang dalam), mereka akhirnya mencapai planet anak itu, tetapi banyak harta karun jatuh. Pesta pergi ke rumah Dr. Capek dan belajar tentang \"Rencana Reproduksi Robot\" Ratu Jane untuk menghilangkan emosi robot yang berasal dari hilangnya ayah pendendam sebelumnya dan dukungan Komandan.",
            "adalah film petualangan fiksi ilmiah animasi Jepang, danfilm Doraemon pertamayang dirilis selama era Reiwa . Ini merayakan 50 tahunfranchise Doraemon , bersama Stand by Me Doraemon 2 . [1] Skenario Doraemon: Nobita's New Dinosaur ditulis oleh Genki Kawamura, yang memproduksi Your Name , The Boy and the Beast dan Weathering with You .",
            " adalah film anime fiksi ilmiah Jepang. Film ini ditayangkan perdana pada tanggal 1 Maret 2019 [3] [4] Film ini disutradarai oleh Shinnosuke Yakuwa dan skenario oleh Mizuki Tsujimura . [5] Ini adalah film Doraemon era Heisei terakhir, dirilis dua bulan sebelum transisi kekaisaran Jepang tahun 2019 .",
            "adalahfilm Doraemon berdurasi panjangyang ditayangkan perdana pada tanggal 4 Maret 2000 di Jepang, berdasarkan volume ke-20 dengan nama yang sama dariseri Cerita Panjang Doraemon . Ceritanya adalah perubahan dari cerita The Prince and the Pauper oleh Mark Twain dan Snow White oleh Brothers Grimm sebagai dua karakter utama yang bertukar tempat.",
            "ni adalah film Doraemon ke-38. Cerita ini didasarkan padanovel Treasure Island karya Robert Louis Stevenson tahun 1883, dengan skenario yang ditulis oleh Genki Kawamura - produser Your Name dan The Boy and the Beast . Kazuaki Imai, seorang sutradara episode dianime televisi Doraemon , mengarahkan proyek tersebut sebagaifilm franchise Doraemon pertamanya.[2] Film ini dirilis pada 3 Maret 2018 di Jepang",
            "adalah film fiksi ilmiah anime 1986berdasarkan volume ketujuh dengan nama yang sama dariseri Cerita Panjang Doraemon . Plot aslinya ditulis oleh Fujiko F. Fujio . Judul alternatif termasuk The Platoon of Iron Men, atau The Robot Army. Film ini memberi penghormatan kepada banyak serial anime yang menampilkan robot raksasa atau \" mecha \", terutama Gundam dan Mazinger . Ini film Doraemon ke-7.",
            "adalah film drama komedi fiksi ilmiah animasi komputer 3D Jepang tahun 2014 yang didasarkan padaserial manga Doraemon dan disutradarai oleh Ryūichi Yagi dan Takashi Yamazaki . [2] Film ini dirilis pada 8 Agustus 2014. [3] [4] Ini adalah film dengan pendapatan kotor tertinggi dari franchise Doraemon. Bang Zoom! Hiburan menayangkan versi bahasa Inggris dari film tersebut di Festival Film Internasional Tokyo pada tanggal 24 Oktober 2014",
            " adalah film drama komedi fiksi ilmiah animasi komputer 3D Jepangberdasarkanserial manga Doraemon dan sekuel dari film 2014 Stand by Me Doraemon . Disutradarai oleh Ryūichi Yagi dan Takashi Yamazaki , sebagian besar didasarkan pada film pendek Doraemon tahun 2000, Doraemon: A Grandmother's Recollections dan secara singkat didasarkan pada film pendek Doraemon tahun 2002 The Day When I Was Born "
    };


    private static int[] movieImages = {
            R.drawable.doraemon1,
            R.drawable.doraemon2,
            R.drawable.doraemon6,
            R.drawable.doraemon3,
            R.drawable.doraemon4,
            R.drawable.doraemon5,
            R.drawable.doraemon7,
            R.drawable.doraemon8,
            R.drawable.doraemon9,
            R.drawable.doraemon10
    };

    static ArrayList<MovieModel> getListData(){
        ArrayList<MovieModel> list = new ArrayList<>();
        for (int position = 0; position < movieNames.length; position++){
           MovieModel moviemodel = new MovieModel();
           moviemodel.setName(movieNames[position]);
           moviemodel.setDetail(movieDetails[position]);
           moviemodel.setPhoto(movieImages[position]);
           list.add(moviemodel);
        }
        return list;
    }
}
